package com.example.madproj;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageButton;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.Calendar;


public class MainActivity extends AppCompatActivity {

    private TableLayout tableLayoutTasks;
    private Button buttonDone;
    private ImageButton imageViewPrevDay;
    private ImageButton imageViewNextDay;
    private TextView textViewDate;
    private Calendar currentDate;
    private static final int ADD_TASK_REQUEST_CODE = 1;
    private int taskId = 0;
    private DatabaseHelper dbHelper; // Database Helper instance

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new DatabaseHelper(this); // Initialize Database Helper

        tableLayoutTasks = findViewById(R.id.tableLayoutTasks);
        buttonDone = findViewById(R.id.buttonDone);
        imageViewPrevDay = findViewById(R.id.imageViewPrevDay);
        imageViewNextDay = findViewById(R.id.imageViewNextDay);
        textViewDate = findViewById(R.id.textViewDate);

        ImageButton imageButtonAddTask = findViewById(R.id.imageButtonAddTask);
        imageButtonAddTask.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivityForResult(new Intent(MainActivity.this, AddTaskActivity.class), ADD_TASK_REQUEST_CODE);
            }
        });

        currentDate = Calendar.getInstance();
        updateDateText();

        imageViewPrevDay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                currentDate.add(Calendar.DAY_OF_MONTH, -1);
                updateDateText();
                updateTasksVisibility();
            }
        });

        imageViewNextDay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                currentDate.add(Calendar.DAY_OF_MONTH, 1);
                updateDateText();
                updateTasksVisibility();
            }
        });

        // Set onClickListener for the "Done" button
        buttonDone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteSelectedTasks();
            }
        });

        loadTasksFromDatabase(); // Load tasks from the database
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == ADD_TASK_REQUEST_CODE && resultCode == RESULT_OK && data != null) {
            String taskName = data.getStringExtra("taskName");
            if (taskName != null && !taskName.isEmpty()) {
                addTask(taskName);
            }
        }
    }

    private void loadTasksFromDatabase() {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        String[] projection = {DatabaseHelper.COLUMN_ID, DatabaseHelper.COLUMN_TASK_NAME, DatabaseHelper.COLUMN_TASK_DATE}; // Include the new column
        Cursor cursor = db.query(DatabaseHelper.TABLE_TASKS, projection, null, null, null, null, null);
        while (cursor.moveToNext()) {
            int taskId = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_ID));
            String taskName = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_TASK_NAME));
            long taskDateMillis = cursor.getLong(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_TASK_DATE)); // Retrieve task date
            addTaskToUI(taskId, taskName, taskDateMillis); // Pass task date to addTaskToUI method
        }
        cursor.close();
    }



    private long addTaskToDatabase(String taskName) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COLUMN_TASK_NAME, taskName);
        long taskDateMillis = currentDate.getTimeInMillis(); // Get the current date in milliseconds
        values.put(DatabaseHelper.COLUMN_TASK_DATE, taskDateMillis); // Store the task date
        long newRowId = db.insert(DatabaseHelper.TABLE_TASKS, null, values);
        return newRowId;
    }


    private void addTaskToUI(int taskId, String taskName, long taskDateMillis) {
        TableRow row = new TableRow(this);
        TableRow.LayoutParams lp = new TableRow.LayoutParams(TableRow.LayoutParams.WRAP_CONTENT);
        row.setLayoutParams(lp);

        final CheckBox checkBox = new CheckBox(this);
        checkBox.setId(taskId);
        checkBox.setText(taskName);
        checkBox.setTextColor(getResources().getColor(android.R.color.white));
        checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                updateDoneButtonVisibility();
            }
        });
        row.addView(checkBox);

        // Store the task's date as a tag
        row.setTag(String.valueOf(taskDateMillis));

        // Compare task's date with current date
        Calendar taskDate = Calendar.getInstance();
        taskDate.setTimeInMillis(taskDateMillis);
        boolean isSameDay = currentDate.get(Calendar.YEAR) == taskDate.get(Calendar.YEAR) &&
                currentDate.get(Calendar.MONTH) == taskDate.get(Calendar.MONTH) &&
                currentDate.get(Calendar.DAY_OF_MONTH) == taskDate.get(Calendar.DAY_OF_MONTH);
        row.setVisibility(isSameDay ? View.VISIBLE : View.GONE);

        tableLayoutTasks.addView(row);
    }


    private void addTask(String taskName) {
        long newRowId = addTaskToDatabase(taskName);
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        String[] projection = {DatabaseHelper.COLUMN_TASK_DATE};
        String selection = DatabaseHelper.COLUMN_ID + " = ?";
        String[] selectionArgs = {String.valueOf(newRowId)};
        Cursor cursor = db.query(DatabaseHelper.TABLE_TASKS, projection, selection, selectionArgs, null, null, null);
        long taskDateMillis = 0;
        if (cursor.moveToFirst()) {
            taskDateMillis = cursor.getLong(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_TASK_DATE));
        }
        cursor.close();
        addTaskToUI(taskId++, taskName, taskDateMillis); // Pass the correct task date to addTaskToUI method
    }


    private void deleteSelectedTasks() {
        SQLiteDatabase db = dbHelper.getWritableDatabase(); // Get the database in write mode
        for (int i = 0; i < tableLayoutTasks.getChildCount(); i++) {
            View view = tableLayoutTasks.getChildAt(i);
            if (view instanceof TableRow) {
                TableRow row = (TableRow) view;
                CheckBox checkBox = (CheckBox) row.getChildAt(0);
                if (checkBox.isChecked()) {
                    // Get the task ID from the checkbox's ID
                    int taskId = checkBox.getId();
                    // Delete the task from the database based on its ID
                    String selection = DatabaseHelper.COLUMN_ID + " = ?";
                    String[] selectionArgs = {String.valueOf(taskId)};
                    db.delete(DatabaseHelper.TABLE_TASKS, selection, selectionArgs);
                    // Remove the row from the UI
                    tableLayoutTasks.removeView(row);
                    i--; // Since we removed a row, decrement i to avoid skipping the next row
                }
            }
        }
        // Hide the "Done" button after deleting selected tasks
        buttonDone.setVisibility(View.GONE);
    }

    private void updateDoneButtonVisibility() {
        // Show the "Done" button if at least one checkbox is checked
        for (int i = 0; i < tableLayoutTasks.getChildCount(); i++) {
            View view = tableLayoutTasks.getChildAt(i);
            if (view instanceof TableRow) {
                TableRow row = (TableRow) view;
                CheckBox checkBox = (CheckBox) row.getChildAt(0);
                if (checkBox.isChecked()) {
                    buttonDone.setVisibility(View.VISIBLE);
                    return;
                }
            }
        }
        // Hide the "Done" button if no checkbox is checked
        buttonDone.setVisibility(View.GONE);
    }

    private void updateDateText() {
        SimpleDateFormat sdf = new SimpleDateFormat("dd MMMM yyyy");
        String dateString = sdf.format(currentDate.getTime());
        textViewDate.setText("Date: " + dateString);
    }



    private void updateTasksVisibility() {
        for (int i = 0; i < tableLayoutTasks.getChildCount(); i++) {
            View view = tableLayoutTasks.getChildAt(i);
            if (view instanceof TableRow) {
                TableRow row = (TableRow) view;
                String tag = (String) row.getTag();
                if (tag != null) {
                    Calendar taskDate = Calendar.getInstance();
                    taskDate.setTimeInMillis(Long.parseLong(tag));
                    boolean isSameDay = currentDate.get(Calendar.YEAR) == taskDate.get(Calendar.YEAR) &&
                            currentDate.get(Calendar.MONTH) == taskDate.get(Calendar.MONTH) &&
                            currentDate.get(Calendar.DAY_OF_MONTH) == taskDate.get(Calendar.DAY_OF_MONTH);
                    row.setVisibility(isSameDay ? View.VISIBLE : View.GONE);
                }
            }
        }
    }
}
